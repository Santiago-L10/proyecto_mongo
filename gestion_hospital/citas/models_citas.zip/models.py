from djongo import models


class DoctorSnapshot(models.Model):
    id = models.CharField(max_length=24)
    nombre_completo = models.CharField(max_length=200)
    especialidad = models.CharField(max_length=150)

    class Meta:
        abstract = True


class PacienteSnapshot(models.Model):
    id = models.CharField(max_length=24)
    id_user = models.CharField(max_length=50)
    nombre_completo = models.CharField(max_length=200)
    telefono = models.CharField(max_length=20)

    class Meta:
        abstract = True

class HorarioMedico(models.Model):
    doctor = models.EmbeddedField(model_container=DoctorSnapshot)
    dia_semana = models.IntegerField()
    minuto_inicio = models.IntegerField()
    minuto_fin = models.IntegerField()
    duracion_consulta_minutos = models.IntegerField()
    zona_horaria = models.CharField(
        max_length=50,
        choices=[('America/Bogota', 'America/Bogota')],
        default='America/Bogota'
    )
    activo = models.CharField(
        max_length=2,
        choices=[('SI', 'SI'), ('NO', 'NO')],
        default='SI'
    )
    fecha_creacion = models.DateTimeField(auto_now_add=True)
    fecha_actualizacion = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "horarios_medicos"


class Cita(models.Model):
    ESTADOS_CITA = [
        ('PROGRAMADA', 'PROGRAMADA'),
        ('EN_ESPERA', 'EN_ESPERA'),
        ('EN_CONSULTA', 'EN_CONSULTA'),
        ('COMPLETADA', 'COMPLETADA'),
        ('CANCELADA', 'CANCELADA'),
    ]

    paciente = models.EmbeddedField(model_container=PacienteSnapshot)
    doctor = models.EmbeddedField(model_container=DoctorSnapshot)
    horario_id = models.CharField(max_length=24, null=True, blank=True)
    fecha_inicio = models.DateTimeField()
    fecha_fin = models.DateTimeField()
    duracion_minutos = models.IntegerField()
    estado = models.CharField(
        max_length=20,
        choices=ESTADOS_CITA,
        default='PROGRAMADA'
    )
    motivo_consulta = models.TextField(null=True, blank=True)
    motivo_cancelacion = models.TextField(null=True, blank=True)
    fecha_creacion = models.DateTimeField(auto_now_add=True)
    fecha_actualizacion = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "citas"